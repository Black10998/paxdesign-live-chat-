import Foundation
import UserNotifications

@MainActor
final class ChatCoordinator: ObservableObject {
    @Published var sessions: [LiveSession] = []
    @Published var liveCount = 0
    @Published var isLoading = false
    @Published var isSyncing = false
    @Published var listRevision = 0
    @Published var lastSyncAt: Date?
    @Published var errorMessage: String?
    @Published var incomingRequest: IncomingLiveRequest? {
        didSet {
            if incomingRequest != nil {
                IncomingCallRingtone.shared.startRinging()
            } else {
                IncomingCallRingtone.shared.stopRinging()
            }
        }
    }
    @Published var activeSessionId: String?

    private var listTask: Task<Void, Never>?
    private var knownLiveRequests = Set<String>()
    private var expiryTasks: [String: Task<Void, Never>] = [:]

    func start(auth: AuthStore) {
        stop()
        SyncDebugStore.shared.listPollLoopActive = true
        SyncDebugStore.shared.setSyncEngineStatus("running")
        listTask = Task { [weak self] in
            while !Task.isCancelled {
                await self?.refreshSessions(auth: auth)
                try? await Task.sleep(nanoseconds: 400_000_000)
            }
        }
    }

    func stop() {
        listTask?.cancel()
        listTask = nil
        SyncDebugStore.shared.listPollLoopActive = false
        SyncDebugStore.shared.setSyncEngineStatus("stopped")
        expiryTasks.values.forEach { $0.cancel() }
        expiryTasks.removeAll()
        IncomingCallRingtone.shared.stopRinging()
    }

    func refreshSessions(auth: AuthStore) async {
        guard let api = auth.api else { return }
        isSyncing = true
        SyncDebugStore.shared.setSyncEngineStatus("syncing")
        defer {
            isSyncing = false
            if SyncDebugStore.shared.listPollLoopActive {
                SyncDebugStore.shared.setSyncEngineStatus("running")
            }
        }
        do {
            let response = try await api.fetchSessions()
            sessions = response.sessions
            liveCount = response.liveCount
            listRevision += 1
            lastSyncAt = Date()
            errorMessage = nil
            SyncDebugStore.shared.recordListDisplayed(count: response.sessions.count, sessions: response.sessions)
            detectIncomingLiveRequests(response.sessions)
        } catch {
            errorMessage = error.localizedDescription
            SyncDebugStore.shared.recordSyncFailure(endpoint: "sessions", error: error)
            SyncDebugStore.shared.setSyncEngineStatus("error")
        }
    }

    private func detectIncomingLiveRequests(_ items: [LiveSession]) {
        let liveOnes = items.filter { $0.isLiveRequest }
        for session in liveOnes {
            guard !knownLiveRequests.contains(session.sessionId) else { continue }
            presentIncoming(session: session)
        }
    }

    func presentIncoming(session: LiveSession) {
        if incomingRequest?.id == session.sessionId { return }
        knownLiveRequests.insert(session.sessionId)
        incomingRequest = IncomingLiveRequest(id: session.sessionId, session: session)
        scheduleExpiry(for: session.sessionId)
    }

    private func scheduleExpiry(for sessionId: String) {
        expiryTasks[sessionId]?.cancel()
        expiryTasks[sessionId] = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 120_000_000_000)
            await MainActor.run {
                guard self?.incomingRequest?.id == sessionId else { return }
                self?.acknowledgeIncomingRequest(sessionId)
            }
        }
    }

    func acknowledgeIncomingRequest(_ sessionId: String) {
        knownLiveRequests.insert(sessionId)
        expiryTasks[sessionId]?.cancel()
        expiryTasks.removeValue(forKey: sessionId)
        if incomingRequest?.id == sessionId {
            incomingRequest = nil
        }
    }

    func acceptLiveRequest(auth: AuthStore, session: LiveSession) async {
        guard let api = auth.api else { return }
        isLoading = true
        defer { isLoading = false }
        do {
            try await api.takeover(session.sessionId)
            acknowledgeIncomingRequest(session.sessionId)
            activeSessionId = session.sessionId
            await refreshSessions(auth: auth)
            PAXHaptics.success()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func declineLiveRequest(auth: AuthStore, session: LiveSession) async {
        guard let api = auth.api else { return }
        isLoading = true
        defer { isLoading = false }
        do {
            try await api.decline(session.sessionId)
            acknowledgeIncomingRequest(session.sessionId)
            await refreshSessions(auth: auth)
            PAXHaptics.warning()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func archiveSession(auth: AuthStore, session: LiveSession) async {
        guard let api = auth.api else { return }
        let sessionId = session.sessionId
        do {
            try await api.archive(sessionId)
            await refreshSessions(auth: auth)
            if activeSessionId == sessionId { activeSessionId = nil }
            PAXHaptics.light()
        } catch {
            errorMessage = error.localizedDescription
            await refreshSessions(auth: auth)
        }
    }

    func deleteSession(auth: AuthStore, session: LiveSession) async {
        guard let api = auth.api else { return }
        let sessionId = session.sessionId
        sessions.removeAll { $0.sessionId == sessionId }
        if activeSessionId == sessionId { activeSessionId = nil }
        do {
            try await api.deleteSession(sessionId)
            await refreshSessions(auth: auth)
            PAXHaptics.warning()
        } catch {
            errorMessage = error.localizedDescription
            await refreshSessions(auth: auth)
        }
    }

    func handlePush(sessionId: String, type: String, auth: AuthStore, payload: PushService.PushPayload? = nil) async {
        switch type {
        case "live_request":
            await presentLiveRequest(sessionId: sessionId, auth: auth, payload: payload)
        case "new_chat", "message":
            await refreshSessions(auth: auth)
            if type == "message" || type == "new_chat" {
                if type == "message" {
                    activeSessionId = sessionId
                }
                postSessionSync(sessionId: sessionId)
            }
        case "session_sync":
            await refreshSessions(auth: auth)
            postSessionSync(sessionId: sessionId)
        default:
            await refreshSessions(auth: auth)
            activeSessionId = sessionId
            postSessionSync(sessionId: sessionId)
        }
    }

    private func postSessionSync(sessionId: String) {
        NotificationCenter.default.post(
            name: .paxSessionSync,
            object: nil,
            userInfo: ["session_id": sessionId]
        )
    }

    func handlePushAction(_ action: String, sessionId: String, auth: AuthStore) async {
        await refreshSessions(auth: auth)
        guard let session = sessions.first(where: { $0.sessionId == sessionId }) else { return }
        switch action {
        case "PAX_ACCEPT":
            await acceptLiveRequest(auth: auth, session: session)
        case "PAX_DECLINE":
            await declineLiveRequest(auth: auth, session: session)
        default:
            await presentLiveRequest(sessionId: sessionId, auth: auth, payload: nil)
        }
    }

    private func presentLiveRequest(sessionId: String, auth: AuthStore, payload: PushService.PushPayload?) async {
        if let existing = sessions.first(where: { $0.sessionId == sessionId && $0.isLiveRequest }) {
            presentIncoming(session: existing)
            return
        }

        await refreshSessions(auth: auth)
        if let session = sessions.first(where: { $0.sessionId == sessionId && $0.isLiveRequest }) {
            presentIncoming(session: session)
            return
        }

        if let payload {
            presentIncoming(session: LiveSession.fromPushPayload(sessionId: sessionId, payload: payload))
        }
    }
}

@MainActor
final class ChatThreadModel: ObservableObject {
    @Published var messages: [LiveMessage] = []
    @Published var handler = "ai"
    @Published var customerName = "Kunde"
    @Published var sessionRating = 0
    @Published var userTyping = false
    @Published var draft = ""
    @Published var isSending = false
    @Published var errorMessage: String?
    @Published var quickReplies: [QuickReply] = []
    @Published var aiSuggestions: [String] = []
    @Published var suggestionsLoading = false
    @Published var suggestionsError: String?

    let sessionId: String
    private weak var auth: AuthStore?
    private var pollSeq = 0
    private var pollTask: Task<Void, Never>?
    private var typingStopTask: Task<Void, Never>?
    private var suggestionsTask: Task<Void, Never>?
    private var suggestionsForMessageId = 0
    private var knownMessageIds = Set<Int>()

    init(sessionId: String) {
        self.sessionId = sessionId
    }

    func start(auth: AuthStore) {
        self.auth = auth
        pollTask?.cancel()
        SyncDebugStore.shared.messagePollLoopActive = true
        SyncDebugStore.shared.selectedSessionId = sessionId
        pollTask = Task { [weak self] in
            guard let self else { return }
            await self.loadQuickReplies(auth: auth)
            await self.loadFull(auth: auth)
            while !Task.isCancelled {
                await self.poll(auth: auth)
                try? await Task.sleep(nanoseconds: 650_000_000)
            }
        }
    }

    func refreshNow(auth: AuthStore) async {
        await poll(auth: auth)
    }

    func stop() {
        pollTask?.cancel()
        pollTask = nil
        SyncDebugStore.shared.messagePollLoopActive = false
        typingStopTask?.cancel()
        typingStopTask = nil
        suggestionsTask?.cancel()
        suggestionsTask = nil
        AdminTypingSound.shared.stop()
    }

    private func loadQuickReplies(auth: AuthStore) async {
        guard let api = auth.api, quickReplies.isEmpty else { return }
        if let response = try? await api.fetchQuickReplies() {
            quickReplies = response.quickReplies
        }
    }

    private func loadFull(auth: AuthStore) async {
        guard let api = auth.api else { return }
        do {
            let data = try await api.fetchSession(sessionId)
            applyPoll(data)
            knownMessageIds = Set(messages.map(\.id))
            if handler == "admin" {
                maybeFetchSuggestionsForLatestUserMessage()
            }
        } catch {
            errorMessage = error.localizedDescription
            SyncDebugStore.shared.recordSyncFailure(endpoint: "poll:\(sessionId):full", error: error)
        }
    }

    private func poll(auth: AuthStore) async {
        guard let api = auth.api else { return }
        do {
            let data = try await api.pollSession(sessionId, since: pollSeq)
            applyPoll(data)
        } catch {
            errorMessage = error.localizedDescription
            SyncDebugStore.shared.recordSyncFailure(endpoint: "poll:\(sessionId)", error: error)
        }
    }

    private func applyPoll(_ data: PollResponse) {
        handler = data.handler
        customerName = data.customerName.isEmpty ? "Kunde" : data.customerName
        if data.sessionRating > 0 {
            sessionRating = data.sessionRating
        }
        userTyping = data.userTyping
        pollSeq = max(pollSeq, data.seq)

        if !data.reactions.isEmpty {
            applyReactions(data.reactions)
        }

        guard !data.messages.isEmpty else {
            SyncDebugStore.shared.recordMessagesDisplayed(count: messages.count, sessionId: sessionId)
            return
        }

        var newUserMessageId = 0
        for msg in data.messages {
            if msg.role == "user" && !knownMessageIds.contains(msg.id) {
                newUserMessageId = msg.id
            }
            knownMessageIds.insert(msg.id)
        }

        var map = Dictionary(uniqueKeysWithValues: messages.map { ($0.id, $0) })
        for msg in data.messages {
            var merged = msg
            if let existing = map[msg.id], merged.reaction == nil {
                merged.reaction = existing.reaction
            }
            map[msg.id] = merged
        }
        messages = map.values.sorted { $0.id < $1.id }

        if newUserMessageId > 0 {
            userTyping = false
        }

        if handler == "admin", newUserMessageId > 0 {
            fetchSuggestions(messageId: newUserMessageId)
        }

        SyncDebugStore.shared.recordMessagesDisplayed(count: messages.count, sessionId: sessionId)
    }

    private func applyReactions(_ reactions: [String: String]) {
        guard !reactions.isEmpty else { return }
        var map = Dictionary(uniqueKeysWithValues: messages.map { ($0.id, $0) })
        for (key, raw) in reactions {
            guard let messageId = Int(key), let reaction = MessageReaction.normalize(raw) else { continue }
            guard var msg = map[messageId], msg.role == "admin" else { continue }
            msg.reaction = reaction
            map[messageId] = msg
        }
        messages = map.values.sorted { $0.id < $1.id }
    }

    func applyQuickReply(_ text: String) {
        draft = text
    }

    func applySuggestion(_ text: String) {
        draft = text
    }

    func fetchSuggestions(messageId: Int) {
        guard handler == "admin", messageId > 0 else { return }
        if suggestionsForMessageId == messageId && !aiSuggestions.isEmpty { return }

        suggestionsTask?.cancel()
        suggestionsForMessageId = messageId
        suggestionsLoading = true
        suggestionsError = nil
        aiSuggestions = []

        suggestionsTask = Task { [weak self] in
            guard let self else { return }
            defer { self.suggestionsLoading = false }
            guard !Task.isCancelled else { return }
            guard let api = self.auth?.api else { return }
            do {
                let response = try await api.fetchSuggestions(sessionId: self.sessionId, messageId: messageId)
                guard !Task.isCancelled, response.messageId == messageId else { return }
                self.aiSuggestions = response.suggestions
                self.suggestionsError = response.suggestions.isEmpty ? "Keine Vorschläge verfügbar." : nil
            } catch {
                guard !Task.isCancelled else { return }
                self.suggestionsError = error.localizedDescription
            }
        }
    }

    func maybeFetchSuggestionsForLatestUserMessage() {
        guard handler == "admin" else {
            clearSuggestions()
            return
        }
        guard let lastUser = messages.last(where: { $0.role == "user" }) else {
            clearSuggestions()
            return
        }
        fetchSuggestions(messageId: lastUser.id)
    }

    func clearSuggestions() {
        suggestionsTask?.cancel()
        suggestionsTask = nil
        aiSuggestions = []
        suggestionsLoading = false
        suggestionsError = nil
        suggestionsForMessageId = 0
    }

    func handleDraftChange(auth: AuthStore) {
        let trimmed = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            AdminTypingSound.shared.stop()
            Task { await notifyTypingStop(auth: auth) }
            return
        }
        AdminTypingSound.shared.typingActivity()
        Task { await notifyTyping(auth: auth) }
    }

    func send(auth: AuthStore) async {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, let api = auth.api else { return }
        AdminTypingSound.shared.stop()
        await notifyTypingStop(auth: auth)
        isSending = true
        defer { isSending = false }
        do {
            let msg = try await api.sendMessage(sessionId, text: text)
            draft = ""
            messages.append(msg)
            knownMessageIds.insert(msg.id)
            pollSeq = max(pollSeq, msg.id)
            clearSuggestions()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func notifyTyping(auth: AuthStore) async {
        typingStopTask?.cancel()
        try? await auth.api?.setTyping(sessionId)
        typingStopTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 1_800_000_000)
            guard !Task.isCancelled, let self else { return }
            try? await auth.api?.setTyping(self.sessionId, stop: true)
        }
    }

    func notifyTypingStop(auth: AuthStore) async {
        typingStopTask?.cancel()
        typingStopTask = nil
        try? await auth.api?.setTyping(sessionId, stop: true)
    }

    func reloadAfterTakeover(auth: AuthStore) async {
        guard let api = auth.api else { return }
        if let data = try? await api.fetchSession(sessionId) {
            handler = data.handler
            customerName = data.customerName.isEmpty ? "Kunde" : data.customerName
            sessionRating = data.sessionRating
            messages = data.messages
            knownMessageIds = Set(messages.map(\.id))
            pollSeq = data.seq
            if !data.reactions.isEmpty {
                applyReactions(data.reactions)
            }
            if handler == "admin" {
                await loadQuickReplies(auth: auth)
                maybeFetchSuggestionsForLatestUserMessage()
            } else {
                clearSuggestions()
            }
        }
    }
}
